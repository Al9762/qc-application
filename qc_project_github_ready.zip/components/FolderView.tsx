
import React, { useState } from 'react';
import { ScannedItem } from '../types';
import { FileSpreadsheetIcon, SearchIcon, ShareIcon } from './Icons';

declare var XLSX: any;

interface FolderViewProps {
  items: ScannedItem[];
  onSelectFolder: (date: string) => void;
}

const FolderView: React.FC<FolderViewProps> = ({ items, onSelectFolder }) => {
  const [searchTerm, setSearchTerm] = useState('');

  // Group items by date
  const groupedItems = items.reduce((acc, item) => {
    const date = new Date(item.timestamp).toLocaleDateString();
    if (!acc[date]) {
      acc[date] = [];
    }
    acc[date].push(item);
    return acc;
  }, {} as Record<string, ScannedItem[]>);

  const dates = Object.keys(groupedItems)
    .sort((a, b) => new Date(b).getTime() - new Date(a).getTime())
    .filter(date => date.toLowerCase().includes(searchTerm.toLowerCase()));

  const handleShare = async (e: React.MouseEvent, date: string) => {
    e.stopPropagation(); // Prevent opening the folder
    const dateItems = groupedItems[date];
    if (!dateItems || dateItems.length === 0) return;

    // Transform data for Excel (Logic matched with TableView)
    const data = dateItems.map((item, index) => {
         const rowData: any = {
            "Row": dateItems.length - index,
            "Date Time": new Date(item.timestamp).toLocaleString(),
            "Name": item.name || "",
            "Code": item.manualCode || "",
        };

        // Try to parse structured data from Code
        // expected format: Key:Value_Key2:Value2
        const parts = item.code.split('_');
        let hasStructuredData = false;

        parts.forEach(part => {
            const separatorIndex = part.indexOf(':');
            if (separatorIndex > 0) {
                const key = part.substring(0, separatorIndex).trim();
                const value = part.substring(separatorIndex + 1).trim();
                if (key && value) {
                    rowData[key] = value;
                    hasStructuredData = true;
                }
            }
        });

        if (!hasStructuredData) {
            rowData["Scanned Data"] = item.code;
        }

        rowData["Format"] = item.format;
        rowData["AI Analysis"] = item.description || "Not analyzed";
        return rowData;
    });

    const wb = XLSX.utils.book_new();
    const ws = XLSX.utils.json_to_sheet(data);
    XLSX.utils.book_append_sheet(wb, ws, "Sheet1");

    // Generate filename
    const cleanTitle = date.replace(/[^a-zA-Z0-9-_]/g, '-');
    const fileName = `SPC_Log_${cleanTitle}.xlsx`;

    try {
        const wbout = XLSX.write(wb, { bookType: 'xlsx', type: 'array' });
        const blob = new Blob([wbout], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
        const file = new File([blob], fileName, { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });

        if (navigator.canShare && navigator.canShare({ files: [file] })) {
            await navigator.share({
                files: [file],
                title: `SPC Log ${date}`,
                text: 'Attached is the scanned QC data.',
            });
        } else {
             XLSX.writeFile(wb, fileName);
        }
    } catch (err) {
        console.error("Share failed", err);
        XLSX.writeFile(wb, fileName);
    }
  };

  return (
    <div className="flex flex-col h-full bg-background p-4 space-y-4 pb-24 overflow-hidden">
      <div className="flex items-center gap-2 text-white mb-2">
        <div className="p-2 bg-green-600/20 rounded-lg">
           <FileSpreadsheetIcon className="w-5 h-5 text-green-400" />
        </div>
        <div>
          <h2 className="font-bold text-lg leading-none">Daily Files</h2>
          <p className="text-xs text-gray-500">Excel reports by date</p>
        </div>
      </div>

      {/* Search Bar */}
      <div className="relative">
        <SearchIcon className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-500" />
        <input
          type="text"
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          placeholder="Search by date..."
          className="w-full bg-surface border border-gray-700 rounded-xl pl-10 pr-4 py-3 text-sm text-white focus:border-primary outline-none transition-colors placeholder-gray-500"
        />
      </div>

      <div className="flex-1 overflow-y-auto no-scrollbar grid grid-cols-2 gap-4 content-start">
        {dates.length === 0 ? (
          <div className="col-span-2 flex flex-col items-center justify-center text-gray-500 p-8 text-center mt-10">
            <FileSpreadsheetIcon className="w-12 h-12 mb-4 opacity-20" />
            <p>No files found.</p>
          </div>
        ) : (
          dates.map(date => (
            <div
              key={date}
              onClick={() => onSelectFolder(date)}
              className="relative bg-surface hover:bg-gray-800 border border-gray-700 rounded-xl p-4 flex flex-col items-center text-center transition-all active:scale-[0.98] cursor-pointer overflow-hidden group"
            >
               {/* Share Button */}
               <button 
                  onClick={(e) => handleShare(e, date)}
                  className="absolute top-2 right-2 p-2 bg-gray-900/30 hover:bg-green-600 text-gray-400 hover:text-white rounded-full backdrop-blur-sm border border-gray-700/50 transition-colors z-10"
                  title="Share this file"
               >
                  <ShareIcon className="w-3 h-3" />
               </button>

              <div className="w-12 h-12 bg-green-900/20 rounded-lg flex items-center justify-center mb-3 text-green-400 border border-green-900/30 group-hover:border-green-500/50 transition-colors mt-2">
                <FileSpreadsheetIcon className="w-6 h-6" />
              </div>
              <span className="text-white font-medium text-sm font-mono">{date}</span>
              <span className="text-[10px] text-gray-500 mt-1 uppercase tracking-wider font-bold">Excel File • {groupedItems[date].length} Rows</span>
            </div>
          ))
        )}
      </div>
    </div>
  );
};

export default FolderView;