import React, { useState, useRef, useEffect } from 'react';
import { Message, Sender, ModelType } from '../types';
import { sendMessage } from '../services/geminiService';
import { SendIcon, LoaderIcon } from './Icons';
import ReactMarkdown from 'react-markdown';

interface ChatViewProps {
  isPro: boolean;
}

const ChatView: React.FC<ChatViewProps> = ({ isPro }) => {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: 'welcome',
      text: "Hello! I'm your Gemini AI assistant. I'm ready to help you manage tasks in the production hall. Ask me anything or paste content to analyze.",
      sender: Sender.BOT,
      timestamp: Date.now()
    }
  ]);
  const [inputText, setInputText] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleSend = async () => {
    if (!inputText.trim()) return;

    const userMsg: Message = {
      id: Date.now().toString(),
      text: inputText,
      sender: Sender.USER,
      timestamp: Date.now()
    };

    setMessages(prev => [...prev, userMsg]);
    setInputText('');
    setIsLoading(true);

    try {
      const model = isPro ? ModelType.PRO : ModelType.FLASH;
      const responseText = await sendMessage(userMsg.text, model);
      
      const botMsg: Message = {
        id: (Date.now() + 1).toString(),
        text: responseText,
        sender: Sender.BOT,
        timestamp: Date.now()
      };
      setMessages(prev => [...prev, botMsg]);
    } catch (error) {
      const errorMsg: Message = {
        id: (Date.now() + 1).toString(),
        text: "Sorry, something went wrong. Please try again.",
        sender: Sender.BOT,
        timestamp: Date.now(),
        isError: true
      };
      setMessages(prev => [...prev, errorMsg]);
    } finally {
      setIsLoading(false);
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  return (
    <div className="flex flex-col h-full relative">
      {/* Background Image for Heavy Steel Structure Production Hall */}
      <div 
        className="absolute inset-0 z-0 bg-cover bg-center pointer-events-none"
        style={{ 
            backgroundImage: "url('https://images.unsplash.com/photo-1581091226825-a6a2a5aee158?q=80&w=1000&auto=format&fit=crop')",
        }}
      >
        <div className="absolute inset-0 bg-background/90 backdrop-blur-[2px]"></div>
      </div>

      <div className="flex-1 overflow-y-auto p-4 space-y-4 pb-24 no-scrollbar z-10">
        {messages.map((msg) => (
          <div
            key={msg.id}
            className={`flex ${msg.sender === Sender.USER ? 'justify-end' : 'justify-start'}`}
          >
            <div
              className={`max-w-[85%] rounded-2xl p-4 text-sm leading-relaxed shadow-sm backdrop-blur-sm ${
                msg.sender === Sender.USER
                  ? 'bg-primary/90 text-white rounded-br-none'
                  : 'bg-surface/80 text-gray-100 rounded-bl-none border border-gray-700'
              } ${msg.isError ? 'bg-red-900/50 border-red-700' : ''}`}
            >
              {msg.sender === Sender.BOT ? (
                 <ReactMarkdown className="markdown-body prose prose-invert prose-sm max-w-none">
                  {msg.text}
                 </ReactMarkdown>
              ) : (
                msg.text
              )}
            </div>
          </div>
        ))}
        {isLoading && (
          <div className="flex justify-start">
             <div className="bg-surface/80 rounded-2xl rounded-bl-none p-4 border border-gray-700 flex items-center gap-2 backdrop-blur-sm">
                <LoaderIcon className="w-4 h-4 animate-spin text-primary" />
                <span className="text-xs text-gray-400">Thinking...</span>
             </div>
          </div>
        )}
        <div ref={messagesEndRef} />
      </div>

      <div className="absolute bottom-0 left-0 right-0 bg-background/95 backdrop-blur-md border-t border-gray-800 p-4 pb-4 z-20">
        <div className="flex items-center gap-2 bg-surface rounded-full px-4 py-2 border border-gray-700 focus-within:border-primary transition-colors">
          <input
            type="text"
            value={inputText}
            onChange={(e) => setInputText(e.target.value)}
            onKeyDown={handleKeyDown}
            placeholder={isPro ? "Ask complex questions..." : "Message Gemini..."}
            className="flex-1 bg-transparent border-none outline-none text-white placeholder-gray-500 text-sm h-10"
            disabled={isLoading}
          />
          <button
            onClick={handleSend}
            disabled={isLoading || !inputText.trim()}
            className="p-2 bg-primary rounded-full text-white disabled:opacity-50 disabled:cursor-not-allowed hover:bg-blue-600 transition-colors"
          >
            <SendIcon className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
};

export default ChatView;