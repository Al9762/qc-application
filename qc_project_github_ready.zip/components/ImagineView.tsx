import React, { useState } from 'react';
import { ImageIcon, SparklesIcon, LoaderIcon } from './Icons';
import { generateImage } from '../services/geminiService';

const ImagineView: React.FC = () => {
  const [prompt, setPrompt] = useState('');
  const [generatedImage, setGeneratedImage] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleGenerate = async () => {
    if (!prompt.trim()) return;
    
    setIsLoading(true);
    setError(null);
    setGeneratedImage(null);

    try {
      const base64Img = await generateImage(prompt);
      setGeneratedImage(base64Img);
    } catch (err) {
      setError("Could not generate image. Please try a different prompt or simpler description.");
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="flex flex-col h-full p-4 space-y-6 pb-24 overflow-y-auto no-scrollbar">
      <div className="text-center space-y-2 py-4">
        <div className="inline-flex items-center justify-center p-3 bg-purple-900/30 rounded-full mb-2">
            <SparklesIcon className="w-6 h-6 text-purple-400" />
        </div>
        <h2 className="text-2xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-purple-400 to-pink-400">
            Imagine Anything
        </h2>
        <p className="text-gray-400 text-sm">Powered by Gemini Image Generation</p>
      </div>

      <div className="space-y-4">
        <textarea
            value={prompt}
            onChange={(e) => setPrompt(e.target.value)}
            placeholder="Describe the image you want to create... (e.g., A futuristic city with flying cars at sunset, cyberpunk style)"
            className="w-full bg-surface border border-gray-700 rounded-2xl p-4 text-sm text-white focus:border-purple-500 outline-none min-h-[100px] resize-none"
        />
        
        <button
            onClick={handleGenerate}
            disabled={isLoading || !prompt.trim()}
            className="w-full bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-500 hover:to-pink-500 text-white font-semibold py-3.5 rounded-2xl shadow-lg transition-all active:scale-[0.98] disabled:opacity-50 disabled:scale-100 flex items-center justify-center gap-2"
        >
            {isLoading ? (
                <>
                <LoaderIcon className="w-5 h-5 animate-spin" />
                <span>Creating masterpiece...</span>
                </>
            ) : (
                <>
                <SparklesIcon className="w-5 h-5" />
                <span>Generate Image</span>
                </>
            )}
        </button>
      </div>

      {error && (
          <div className="p-4 bg-red-900/20 border border-red-800 rounded-xl text-red-200 text-sm text-center">
              {error}
          </div>
      )}

      {generatedImage && (
        <div className="space-y-4 animate-fade-in">
            <div className="relative rounded-2xl overflow-hidden shadow-2xl border border-gray-700 bg-black aspect-square">
                <img src={generatedImage} alt="Generated" className="w-full h-full object-contain" />
            </div>
            <a 
                href={generatedImage} 
                download={`gemini-imagine-${Date.now()}.png`}
                className="block w-full text-center py-3 bg-surface border border-gray-700 rounded-xl text-sm font-medium hover:bg-gray-700 transition-colors"
            >
                Download Image
            </a>
        </div>
      )}
    </div>
  );
};

export default ImagineView;