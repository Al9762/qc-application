import React, { useState, useRef } from 'react';
import { CameraIcon, SendIcon, LoaderIcon, PlusIcon } from './Icons';
import { analyzeImage } from '../services/geminiService';
import ReactMarkdown from 'react-markdown';

const VisionView: React.FC = () => {
  const [selectedImage, setSelectedImage] = useState<string | null>(null);
  const [prompt, setPrompt] = useState('');
  const [result, setResult] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setSelectedImage(reader.result as string);
        setResult(null); // Clear previous result
      };
      reader.readAsDataURL(file);
    }
  };

  const handleAnalyze = async () => {
    if (!selectedImage) return;

    setIsLoading(true);
    setResult(null);

    try {
      // Remove data URL prefix for API
      const base64Data = selectedImage.split(',')[1];
      const mimeType = selectedImage.split(';')[0].split(':')[1];
      
      const analysis = await analyzeImage(base64Data, prompt, mimeType);
      setResult(analysis);
    } catch (error) {
      setResult("Failed to analyze image. Please try again.");
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="flex flex-col h-full p-4 space-y-4 pb-24 overflow-y-auto no-scrollbar">
      
      {/* Upload Area */}
      <div 
        className={`relative w-full aspect-square sm:aspect-video rounded-2xl border-2 border-dashed ${selectedImage ? 'border-gray-700' : 'border-gray-600 hover:border-gray-400'} flex flex-col items-center justify-center bg-surface overflow-hidden transition-colors cursor-pointer`}
        onClick={() => !selectedImage && fileInputRef.current?.click()}
      >
        {selectedImage ? (
          <>
            <img src={selectedImage} alt="Preview" className="w-full h-full object-contain bg-black" />
            <button 
              onClick={(e) => {
                e.stopPropagation();
                setSelectedImage(null);
                setResult(null);
              }}
              className="absolute top-2 right-2 bg-black/60 text-white p-2 rounded-full backdrop-blur-md"
            >
              <PlusIcon className="w-5 h-5 rotate-45" />
            </button>
          </>
        ) : (
          <div className="text-center p-6">
            <div className="w-16 h-16 bg-gray-700/50 rounded-full flex items-center justify-center mx-auto mb-4">
               <CameraIcon className="w-8 h-8 text-primary" />
            </div>
            <p className="text-gray-300 font-medium">Take a photo or upload</p>
            <p className="text-gray-500 text-xs mt-2">Tap to select</p>
          </div>
        )}
        <input 
          ref={fileInputRef}
          type="file" 
          accept="image/*" 
          className="hidden" 
          onChange={handleFileChange}
        />
      </div>

      {/* Input Area */}
      <div className="flex flex-col gap-3">
        <label className="text-sm text-gray-400 ml-1">Ask about this image</label>
        <div className="flex gap-2">
            <input
            type="text"
            value={prompt}
            onChange={(e) => setPrompt(e.target.value)}
            placeholder="e.g. What plant is this?"
            className="flex-1 bg-surface border border-gray-700 rounded-xl px-4 py-3 text-sm text-white focus:border-primary outline-none"
            />
            <button
            onClick={handleAnalyze}
            disabled={!selectedImage || isLoading}
            className="bg-primary text-white rounded-xl px-4 flex items-center justify-center disabled:opacity-50 disabled:cursor-not-allowed"
            >
            {isLoading ? <LoaderIcon className="w-5 h-5 animate-spin" /> : <SendIcon className="w-5 h-5" />}
            </button>
        </div>
      </div>

      {/* Result Area */}
      {result && (
        <div className="bg-surface rounded-2xl p-5 border border-gray-700 shadow-lg animate-fade-in">
           <div className="flex items-center gap-2 mb-3 text-primary">
              <CameraIcon className="w-4 h-4" />
              <span className="text-xs font-bold uppercase tracking-wider">Analysis Result</span>
           </div>
           <ReactMarkdown className="markdown-body prose prose-invert prose-sm max-w-none">
             {result}
           </ReactMarkdown>
        </div>
      )}
    </div>
  );
};

export default VisionView;