
import React, { useState } from 'react';
import { ScannedItem } from '../types';
import { DownloadIcon, TrashIcon, SearchIcon, LoaderIcon, TableIcon, ShareIcon, ChevronLeftIcon } from './Icons';
import ReactMarkdown from 'react-markdown';

declare var XLSX: any;

interface TableViewProps {
  items: ScannedItem[];
  onDelete: (id: string) => void;
  onUpdateName: (id: string, name: string) => void;
  onUpdateManualCode: (id: string, code: string) => void;
  onAnalyze: (id: string) => void;
  onClearAll: () => void;
  title?: string;
  onBack?: () => void;
}

const TableView: React.FC<TableViewProps> = ({ items, onDelete, onUpdateName, onUpdateManualCode, onAnalyze, onClearAll, title = "History", onBack }) => {
  const [searchTerm, setSearchTerm] = useState('');
  
  const handleShare = async () => {
    if (items.length === 0) return;

    // Transform data for Excel
    const data = items.map((item, index) => {
        // Basic Row Data
        const rowData: any = {
            "Row": items.length - index,
            "Date Time": new Date(item.timestamp).toLocaleString(),
            "Name": item.name || "",
            "Code": item.manualCode || "",
        };

        // Try to parse structured data from Code
        // expected format: Key:Value_Key2:Value2
        const parts = item.code.split('_');
        let hasStructuredData = false;

        parts.forEach(part => {
            // Check for Key:Value pattern
            const separatorIndex = part.indexOf(':');
            if (separatorIndex > 0) {
                const key = part.substring(0, separatorIndex).trim();
                const value = part.substring(separatorIndex + 1).trim();
                
                if (key && value) {
                    rowData[key] = value;
                    hasStructuredData = true;
                }
            }
        });

        // If no structured data was found, keep the original Code Content column
        if (!hasStructuredData) {
            rowData["Scanned Data"] = item.code;
        }

        // Add standard fields
        rowData["Format"] = item.format;
        rowData["AI Analysis"] = item.description || "Not analyzed";

        return rowData;
    });

    const wb = XLSX.utils.book_new();
    const ws = XLSX.utils.json_to_sheet(data);
    XLSX.utils.book_append_sheet(wb, ws, "Sheet1");
    
    // Generate a clean filename based on title (which is the date in File view)
    // Replace slashes with dashes for filename safety
    const cleanTitle = title.replace(/[^a-zA-Z0-9-_]/g, '-');
    const fileName = `SPC_Log_${cleanTitle}.xlsx`;

    try {
        // Attempt to use Web Share API with a file
        const wbout = XLSX.write(wb, { bookType: 'xlsx', type: 'array' });
        const blob = new Blob([wbout], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
        const file = new File([blob], fileName, { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });

        if (navigator.canShare && navigator.canShare({ files: [file] })) {
            await navigator.share({
                files: [file],
                title: `SPC Log ${title}`,
                text: 'Attached is the scanned QC data.',
            });
        } else {
            // Fallback to standard download
             XLSX.writeFile(wb, fileName);
        }
    } catch (err) {
        console.error("Share failed, falling back to download", err);
        XLSX.writeFile(wb, fileName);
    }
  };

  const filteredItems = items.filter(item => 
    item.code.toLowerCase().includes(searchTerm.toLowerCase()) || 
    (item.name && item.name.toLowerCase().includes(searchTerm.toLowerCase())) ||
    (item.manualCode && item.manualCode.toLowerCase().includes(searchTerm.toLowerCase()))
  );

  return (
    <div className="flex flex-col h-full bg-background p-4 space-y-4 pb-24 overflow-hidden">
      
      {/* Header */}
      <div className="flex items-center justify-between mb-2">
        <div className="flex items-center gap-2 text-white">
          {onBack ? (
              <button onClick={onBack} className="p-2 hover:bg-gray-800 rounded-full transition-colors -ml-2">
                  <ChevronLeftIcon className="w-6 h-6 text-white" />
              </button>
          ) : (
              <div className="p-2 bg-green-600/20 rounded-lg">
                 <TableIcon className="w-5 h-5 text-green-400" />
              </div>
          )}
          
          <div>
            <h2 className="font-bold text-lg leading-none">{title}</h2>
            <p className="text-xs text-gray-500">{items.length} records found</p>
          </div>
        </div>
        
        <div className="flex gap-2">
           <button 
             onClick={onClearAll}
             disabled={items.length === 0}
             className="p-2 bg-red-900/30 text-red-400 rounded-lg disabled:opacity-30 transition-colors hover:bg-red-900/40"
             title="Clear All"
           >
             <TrashIcon className="w-5 h-5" />
           </button>
           <button 
             onClick={handleShare}
             disabled={items.length === 0}
             className="flex items-center gap-2 bg-green-600 hover:bg-green-500 text-white px-3 py-2 rounded-lg text-sm font-semibold transition-colors disabled:opacity-50 disabled:grayscale"
           >
             <ShareIcon className="w-4 h-4" />
             Share
           </button>
        </div>
      </div>

      {/* Search Bar */}
      <div className="relative">
        <SearchIcon className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-500" />
        <input
          type="text"
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          placeholder="Search code or name..."
          className="w-full bg-surface border border-gray-700 rounded-xl pl-10 pr-4 py-3 text-sm text-white focus:border-primary outline-none transition-colors placeholder-gray-500"
        />
      </div>

      {/* Table Area - Styled to look like a grid/excel */}
      <div className="flex-1 overflow-auto rounded-xl border border-gray-700 bg-surface/50 no-scrollbar relative">
        {items.length === 0 ? (
           <div className="absolute inset-0 flex flex-col items-center justify-center text-gray-500 p-8 text-center">
              <TableIcon className="w-12 h-12 mb-4 opacity-20" />
              <p>This file is empty.</p>
           </div>
        ) : (
          <table className="w-full text-left border-collapse text-sm">
            <thead className="bg-gray-800 text-gray-400 sticky top-0 z-10">
              <tr>
                <th className="p-3 font-medium border-b border-gray-700 w-10 text-center">#</th>
                <th className="p-3 font-medium border-b border-gray-700 w-28">Name</th>
                <th className="p-3 font-medium border-b border-gray-700 w-28">Code</th>
                <th className="p-3 font-medium border-b border-gray-700">Scanned Data</th>
                <th className="p-3 font-medium border-b border-gray-700">Analysis</th>
                <th className="p-3 font-medium border-b border-gray-700 w-12 text-center">Act</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-700/50">
              {filteredItems.length === 0 ? (
                <tr>
                  <td colSpan={6} className="p-8 text-center text-gray-500">
                    No results found for "{searchTerm}"
                  </td>
                </tr>
              ) : (
                filteredItems.map((item, index) => {
                  const isRecent = (Date.now() - item.timestamp) < 5000;
                  return (
                    <tr key={item.id} className={`hover:bg-gray-700/30 transition-colors ${isRecent ? 'animate-highlight' : ''}`}>
                      <td className="p-3 text-gray-500 font-mono text-xs text-center">{filteredItems.length - index}</td>
                      <td className="p-3 align-top">
                        <input 
                            type="text" 
                            value={item.name || ''} 
                            onChange={(e) => onUpdateName(item.id, e.target.value)}
                            className="bg-transparent border-b border-gray-700 focus:border-primary outline-none text-white w-full text-sm py-1"
                            placeholder="-"
                        />
                      </td>
                      <td className="p-3 align-top">
                        <input 
                            type="text" 
                            value={item.manualCode || ''} 
                            onChange={(e) => onUpdateManualCode(item.id, e.target.value)}
                            className="bg-transparent border-b border-gray-700 focus:border-primary outline-none text-white w-full text-sm py-1 font-mono"
                            placeholder="-"
                        />
                      </td>
                      <td className="p-3 align-top">
                        <div className="font-mono text-white break-all text-xs">{item.code}</div>
                        <div className="flex gap-2 mt-1">
                          <span className="text-[10px] bg-gray-700 px-1.5 py-0.5 rounded text-gray-300">{item.format}</span>
                          <span className="text-[10px] text-gray-500">{new Date(item.timestamp).toLocaleTimeString()}</span>
                        </div>
                      </td>
                      <td className="p-3 align-top min-w-[120px]">
                        {item.description ? (
                          <div className="text-gray-300 text-xs">
                              <ReactMarkdown className="markdown-body prose prose-invert prose-xs max-w-none">
                                {item.description}
                              </ReactMarkdown>
                          </div>
                        ) : (
                          <button
                            onClick={() => onAnalyze(item.id)}
                            disabled={item.isLoading}
                            className="flex items-center gap-1.5 text-blue-400 hover:text-blue-300 text-xs font-medium bg-blue-900/20 px-2 py-1.5 rounded-md border border-blue-900/50 transition-colors w-full justify-center"
                          >
                            {item.isLoading ? <LoaderIcon className="w-3 h-3 animate-spin" /> : <SearchIcon className="w-3 h-3" />}
                            {item.isLoading ? "..." : "Analyze"}
                          </button>
                        )}
                      </td>
                      <td className="p-3 align-top text-center">
                        <button 
                          onClick={() => onDelete(item.id)}
                          className="text-gray-600 hover:text-red-400 transition-colors p-1"
                        >
                          <TrashIcon className="w-4 h-4" />
                        </button>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
};

export default TableView;