import React, { useEffect, useState, useRef } from 'react';
import { QrCodeIcon, XIcon, CheckIcon } from './Icons';
import { ScannedItem } from '../types';

interface ScannerViewProps {
  onScan: (code: string, format: string) => void;
}

const ScannerView: React.FC<ScannerViewProps> = ({ onScan }) => {
  const [isScanning, setIsScanning] = useState(false);
  const [lastScanned, setLastScanned] = useState<string | null>(null);
  const scannerRef = useRef<any>(null);
  const regionId = "reader";
  const scannerTimeoutRef = useRef<any>(null);

  // Cleanup scanner on unmount
  useEffect(() => {
    return () => {
      stopScanner();
    };
  }, []);

  const startScanner = async () => {
    setIsScanning(true);
    setLastScanned(null);
    
    // Slight delay to ensure DOM is ready
    setTimeout(() => {
      const html5QrcodeScanner = new (window as any).Html5Qrcode(regionId);
      scannerRef.current = html5QrcodeScanner;

      const config = { 
        fps: 10, 
        qrbox: { width: 250, height: 250 },
        formatsToSupport: [ 
             (window as any).Html5QrcodeSupportedFormats.QR_CODE,
             (window as any).Html5QrcodeSupportedFormats.EAN_13,
             (window as any).Html5QrcodeSupportedFormats.CODE_128,
             (window as any).Html5QrcodeSupportedFormats.DATA_MATRIX
        ] 
      };
      
      html5QrcodeScanner.start(
        { facingMode: "environment" }, 
        config,
        onScanSuccess,
        (errorMessage: any) => {
          // ignore frame errors
        }
      ).catch((err: any) => {
         console.error("Error starting scanner", err);
         setIsScanning(false);
      });
    }, 100);
  };

  const stopScanner = async () => {
     if (scannerRef.current) {
         try {
             await scannerRef.current.stop();
             await scannerRef.current.clear();
             scannerRef.current = null;
         } catch (e) {
             console.error("Failed to stop scanner", e);
         }
     }
     setIsScanning(false);
  };

  const onScanSuccess = (decodedText: string, decodedResult: any) => {
      // Prevent duplicate rapid scans of the same code
      if (lastScanned === decodedText) return;

      if (navigator.vibrate) navigator.vibrate(200);

      const format = decodedResult?.result?.format?.formatName || 'QR_CODE';
      
      // Notify Parent
      onScan(decodedText, format);
      
      // Local Feedback
      setLastScanned(decodedText);
      
      // Pause scanning briefly for visual feedback
      stopScanner();
  };

  return (
    <div className="flex flex-col h-full relative overflow-hidden bg-black">
      
      {/* Scanner Viewport */}
      {isScanning ? (
        <div className="flex-1 relative flex flex-col">
            <div id={regionId} className="w-full h-full bg-black"></div>
            
            {/* Overlay UI */}
            <div className="absolute top-0 left-0 right-0 p-8 flex justify-center z-20">
                 <div className="bg-black/60 backdrop-blur-md px-4 py-2 rounded-full text-white text-sm border border-white/10">
                    Align code within frame
                 </div>
            </div>

            <button 
                onClick={stopScanner}
                className="absolute bottom-24 left-1/2 -translate-x-1/2 bg-red-500/80 text-white p-4 rounded-full backdrop-blur-md z-20 shadow-lg border border-red-400/50"
            >
                <XIcon className="w-6 h-6" />
            </button>
        </div>
      ) : (
        /* Idle / Result View */
        <div className="flex-1 flex flex-col items-center justify-center p-6 space-y-8 bg-surface/30">
            
            {/* Last Scanned Result Card */}
            {lastScanned ? (
                <div className="w-full max-w-sm bg-green-900/20 border border-green-500/30 p-6 rounded-2xl flex flex-col items-center text-center animate-fade-in">
                    <div className="w-16 h-16 bg-green-500 rounded-full flex items-center justify-center mb-4 text-black shadow-lg shadow-green-500/20">
                        <CheckIcon className="w-8 h-8" />
                    </div>
                    <h3 className="text-white font-bold text-xl mb-1">Scan Successful</h3>
                    <p className="text-green-400 font-mono text-sm break-all bg-black/30 px-3 py-1 rounded-lg">
                        {lastScanned}
                    </p>
                    <p className="text-gray-400 text-xs mt-4">Data saved to Table</p>
                    
                    <button 
                        onClick={startScanner}
                        className="mt-6 w-full bg-primary hover:bg-blue-500 text-white py-3 rounded-xl font-semibold transition-transform active:scale-95 shadow-lg"
                    >
                        Scan Next
                    </button>
                </div>
            ) : (
                /* Initial State */
                <div className="flex flex-col items-center text-center">
                    <div className="w-24 h-24 bg-gray-800 rounded-full flex items-center justify-center mb-6 border border-gray-700">
                        <QrCodeIcon className="w-10 h-10 text-gray-400" />
                    </div>
                    <h2 className="text-2xl font-bold text-white mb-2">Ready to Scan</h2>
                    <p className="text-gray-400 max-w-xs mb-8">
                        Point your camera at a QR code or Barcode. Data will be automatically added to the data sheet.
                    </p>
                    <button 
                        onClick={startScanner}
                        className="bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 text-white px-8 py-4 rounded-2xl font-bold text-lg shadow-xl shadow-blue-900/30 transition-transform active:scale-95 flex items-center gap-2"
                    >
                        <QrCodeIcon className="w-6 h-6" />
                        Start Scanner
                    </button>
                </div>
            )}
        </div>
      )}
    </div>
  );
};

export default ScannerView;