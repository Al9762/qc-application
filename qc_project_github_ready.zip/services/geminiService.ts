import { GoogleGenAI, GenerateContentResponse } from "@google/genai";
import { ModelType } from "../types";

// Initialize the client. API_KEY is injected by the environment.
const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

/**
 * Sends a text message to the model.
 */
export const sendMessage = async (
  prompt: string,
  model: ModelType = ModelType.FLASH,
  history: { role: string; parts: { text: string }[] }[] = []
): Promise<string> => {
  try {
    const response: GenerateContentResponse = await ai.models.generateContent({
      model: model,
      contents: prompt, // Simple text prompt
      config: {
        systemInstruction: "You are a helpful, concise mobile AI assistant for a heavy steel structure manufacturing company. Keep answers brief and optimized for mobile reading unless asked for detail.",
      }
    });

    return response.text || "No response generated.";
  } catch (error) {
    console.error("Gemini API Error:", error);
    throw error;
  }
};

/**
 * Analyzes an image with a text prompt.
 */
export const analyzeImage = async (
  base64Image: string,
  prompt: string,
  mimeType: string = "image/jpeg"
): Promise<string> => {
  try {
    const response: GenerateContentResponse = await ai.models.generateContent({
      model: ModelType.FLASH, // Flash is great for multimodal
      contents: {
        parts: [
          {
            inlineData: {
              mimeType: mimeType,
              data: base64Image,
            },
          },
          {
            text: prompt || "Describe this image.",
          },
        ],
      },
    });

    return response.text || "Could not analyze image.";
  } catch (error) {
    console.error("Gemini Vision Error:", error);
    throw error;
  }
};

/**
 * Generates an image using the Gemini Nano/Image model.
 */
export const generateImage = async (prompt: string): Promise<string> => {
  try {
    const response: GenerateContentResponse = await ai.models.generateContent({
      model: ModelType.IMAGE,
      contents: {
        parts: [
          {
            text: prompt,
          },
        ],
      },
      config: {
        // Nano Banana / Flash Image specific configs if needed
        // Note: responseMimeType is not supported for this model
      }
    });

    // Parse response for image data
    if (response.candidates && response.candidates[0].content.parts) {
      for (const part of response.candidates[0].content.parts) {
        if (part.inlineData) {
          return `data:${part.inlineData.mimeType};base64,${part.inlineData.data}`;
        }
      }
    }
    
    throw new Error("No image data found in response.");
  } catch (error) {
    console.error("Gemini Image Gen Error:", error);
    throw error;
  }
};

/**
 * Identifies a product based on its barcode or QR code.
 */
export const identifyProduct = async (code: string): Promise<string> => {
    try {
        const response: GenerateContentResponse = await ai.models.generateContent({
            model: ModelType.FLASH,
            contents: `I have scanned a QR code or barcode with the value: "${code}". 
            
            Please analyze this value:
            1. If it looks like a URL, explain what kind of website it might be or what it links to.
            2. If it is a product code (EAN, UPC, etc.), identify the product.
            3. If it looks like a serial number or internal part code for a steel structure, mention that.
            4. If it's just raw text, summarize it.
            
            Keep the response concise and helpful for a worker on a factory floor.`,
            config: {
                systemInstruction: "You are an expert industrial assistant. Analyze codes and data with a focus on manufacturing and utility.",
            }
        });
        return response.text || "Could not identify content.";
    } catch (error) {
        console.error("Gemini Product ID Error:", error);
        throw error;
    }
}